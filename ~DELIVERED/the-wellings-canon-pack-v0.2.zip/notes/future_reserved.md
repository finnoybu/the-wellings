The following are NOT in canon yet:
- Interiors of all houses
- Mr. Linden
- Mr. & Mrs. Sanchez

Do not invent or infer details for these.
