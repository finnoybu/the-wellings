# The Wellings — Canon Pack

This folder contains the authoritative canon reference
for *The Wellings* children's book franchise.

All characters, environments, and stylistic rules
must conform to the documents in this pack.

Conceptual materials are explicitly labeled and
are not binding unless promoted to canon.
