## Open-Book Concept Art

Images in `open-book-concepts/` are conceptual marketing illustrations.

They are intended for:
- website headers
- promotional pages
- franchise overviews

These images are not tied to print layouts or canon scenes.
Similar open-book illustrations may be created for individual books in the future.
