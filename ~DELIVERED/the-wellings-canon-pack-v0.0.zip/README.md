This is the LOCKED CANON PACK for "The Wellings".

All images and descriptions in this archive are authoritative.
No deviations are permitted unless explicitly revised by the author.

If a request conflicts with canon, stop and ask.
