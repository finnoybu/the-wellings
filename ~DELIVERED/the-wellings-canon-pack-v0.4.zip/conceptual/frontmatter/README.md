Front matter images are conceptual references; no canonical front-matter text exists yet.
Frontmatter assets are reusable templates across books unless otherwise noted.