This folder contains print-production reference materials.

Files here are NOT canon and NOT final.
They exist to explore trim size, spine width, and layout constraints
for platforms such as Amazon KDP.

Final production assets will replace these drafts.
